

def func1(num):
    s = set()
    for i in num:
        if i in s:
            return True
        s.add(i)
    return False

print(func1([1,2,3,4]))