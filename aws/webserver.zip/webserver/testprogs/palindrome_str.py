def palindrome_str(s1):
    s = str(s1)
    print(s)
    for i in range(len(s)//2):
        print(i)
        if s[i] != s[len(s)-1-i]:
            return False
    return True

s = 1220
print(palindrome_str(s))