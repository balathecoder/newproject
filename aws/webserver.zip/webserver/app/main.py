from fastapi import FastAPI, HTTPException, status, Depends
import schemas, models
from typing import List
from sqlalchemy.orm import Session
from database import engine, get_db

app = FastAPI()

# create database tables
models.Base.metadata.create_all(bind=engine)

# create an product
@app.post('/products', status_code=status.HTTP_201_CREATED)
async def create_product(product: schemas.Product, db: Session = Depends(get_db)):
    print('post api is called')
    new_product = models.Product(name=product.name, description=product.description, price=product.price)
    db.add(new_product)
    db.commit()
    db.refresh(new_product)
    return 'created'

@app.get('/products/{product_id}',response_model=schemas.Product, status_code=status.HTTP_200_OK)
async def get_products(product_id: int, db: Session = Depends(get_db)):
    print('get api for a product is called')
    product = db.query(models.Product).filter(models.Product.id == product_id).first()
    if not product: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Product not found')
    return product

@app.get('/products',response_model=List[schemas.Product], status_code=status.HTTP_200_OK)
async def get_products_all(db: Session = Depends(get_db)):
    print('get api for all product is called')
    products = db.query(models.Product).all()
    if not products: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail='Products not found')
    return products

@app.put("/product/{product_id}",  status_code=status.HTTP_202_ACCEPTED)
async def update_item(product_id: int, product: schemas.Product, db: Session = Depends(get_db)):
    print('put api is called')
    current_product = db.query(models.Product).filter(models.Product.id == product_id)
    if not product: raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Product not found")
    current_product.update(dict(product))
    db.commit()
    return 'accepted'

@app.delete("/product/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_item(product_id: int, db: Session = Depends(get_db)):
    print('delete api is called')
    product = db.query(models.Product).filter(schemas.Product.id == product_id)
    if not product:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Item not found")
    product.delete(synchronize_session=False)
    db.commit()
    return 'deleted'