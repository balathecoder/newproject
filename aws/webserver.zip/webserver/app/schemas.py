
from pydantic import BaseModel  # FastAPI uses pydantic for validation and serialization.

class BaseProduct(BaseModel):
    name: str
    description: str
    price: int

class Product(BaseProduct):
    class Config:
        #orm_mode = True   # on Pydantic v1. Helps to serialize database models result to Pydantic schema 
        from_attributes = True   # from pydantic v2, need to use from_attributes.