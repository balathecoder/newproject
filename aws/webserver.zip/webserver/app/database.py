from sqlalchemy import create_engine, Column, Integer, String
import sqlalchemy
import sqlalchemy.ext
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
import os
ENV = os.getenv("ENV","development").lower()
if ENV == "development":
    # Database setup
    DATABASE_URL = "sqlite:///./product_db.db"
    # create sqlalchemy engine
    engine = create_engine(DATABASE_URL, connect_args={"check_same_thread":False})

else:
    username = os.getenv("DB_USER","postgres")
    password = os.getenv("DB_PSWD","postgres")
    host = os.getenv("DB_HOST","")
    port = os.getenv("DB_PORT",5432)
    database = os.getenv("DB_NAME","products")
    db_type = os.getenv("DB_TYPE","mysql")
    DATABASE_URL = f'{db_type}://{username}:{password}@{host}:{port}/{database}'
    engine = create_engine(DATABASE_URL, pool_size=15, max_overflow=20, pool_timeout=60, pool_recycle=1800)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()