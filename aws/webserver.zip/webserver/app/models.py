from sqlalchemy import Column, Integer, String, ForeignKey
from decimal import Decimal
from database import Base
class Product(Base):
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String)
    description = Column(String)
    price = Column(Integer)
    #price = Decimal = Field(ge=0.01, decimal_places=2)